export PUPPETSERVER_IMAGE=puppet/puppetserver:5.0.0
export PUPPETDB_IMAGE=puppet/puppetdb:5.0.1
export DNS_ALT_NAMES=host.example.com
export PUPPERWARE_ANALYTICS_ENABLED=false
export ADDITIONAL_COMPOSE_SERVICES_PATH=${PWD}/gem/lib/pupperware/compose-services
export COMPOSE_FILE=${ADDITIONAL_COMPOSE_SERVICES_PATH}/postgres.yml:${ADDITIONAL_COMPOSE_SERVICES_PATH}/puppetdb.yml:${ADDITIONAL_COMPOSE_SERVICES_PATH}/puppet.yml
docker-compose up

